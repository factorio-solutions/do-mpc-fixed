# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['do_mpc', 'do_mpc.sampling', 'do_mpc.tools']

package_data = \
{'': ['*']}

install_requires = \
['Sphinx>=5.0.2,<6.0.0',
 'docutils>=0.14,<0.19',
 'graphviz>=0.20,<0.21',
 'ipykernel>=6.15.1,<7.0.0',
 'matplotlib>=3.5.2,<4.0.0',
 'nbsphinx>=0.8.9,<0.9.0',
 'numpy>=1.23.1,<2.0.0',
 'pygments>=2.12.0,<3.0.0',
 'recommonmark>=0.7.1,<0.8.0',
 'scipy>=1.8.1,<2.0.0',
 'sphinx-copybutton>=0.5.0,<0.6.0']

setup_kwargs = {
    'name': 'do-mpc',
    'version': '4.3.5.1',
    'description': 'Fix for Sparsity error',
    'long_description': None,
    'author': 'Martin Ron',
    'author_email': 'martin.ron@factorio.cz',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.9,<3.11',
}


setup(**setup_kwargs)
